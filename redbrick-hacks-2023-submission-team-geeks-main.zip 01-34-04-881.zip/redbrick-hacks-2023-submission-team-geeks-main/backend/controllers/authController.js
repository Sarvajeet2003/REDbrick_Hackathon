const donorModel = require("../models/donorModel")
const ngoModel = require("../models/ngoModel")
const nodemailer = require('nodemailer')
const sendEmail = async (name, email) => {
    if (email&&name) {
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: "tusharc20001@gmail.com",
                pass: "udfmjqntdpovoaoi",
            },
        });
        const mailoptions = {
            from: "tusharc20001@gmail.com",
            to: email,
            subject: "Thanks for registering!",
            html: `Hello <b>${name}</b>, <br>Thank you for registering on <b>Mancmint</b>.<br>`
        }
        // res.status(200).json({
        //     message:"Otp sent successfully"
        // })
        await transporter.sendMail(mailoptions)
    }
    else {
        res.status(400).json({
            message: "Email is required"
        })
    }
}
const userRegister = async (req, res) => {
    const { name, email, phone_no, password, isDonor } = req.body
    try {
        if (name && email && phone_no && password && isDonor) {
            if (isDonor == 1) {
                const isUserPresent = await donorModel.findOne({ email: email, phone_no: phone_no })
                if (!isUserPresent) {
                    await donorModel.create({
                        name: name,
                        email: email,
                        phone_no: phone_no,
                        password: password,
                    })
                    sendEmail(name, email)
                    return res.json({ message: "Registration successful!" });
                }
                else {
                    res.status(403).json({ message: "User already present with these credentials!" })
                    throw new Error("User already present with these credentials!")
                }
            }
            else {
                const isUserPresent = await ngoModel.findOne({ email: email, phone_no: phone_no })
                if (!isUserPresent) {
                    await ngoModel.create({
                        name: name,
                        email: email,
                        phone_no: phone_no,
                        password: password,
                    })
                    sendEmail(name, email)
                    return res.json({ message: "Registration successful!" });
                }
                else {
                    res.status(403).json({ message: "User already present with these credentials!" })
                    throw new Error("User already present with these credentials!")
                }
            }
        }
        else {
            res.status(403).json({message : "Please fill all the fields!"})
            throw new Error("Please fill all the fields!")
        }
    }
    catch(err) {
        res.status(400)
        throw new Error(err)
    }
}
const userLogin = async (req, res) => {
    const { email, password, isDonor } = req.body
    try {
        if (email && password) {
            if (isDonor == 1) {
                const isUserPresent = await donorModel.findOne({ email })
                if (isUserPresent) {
                    if (password != isUserPresent.password) {
                        res.status(402).json({ message: "Password incorrect" })
                        throw new Error("Password incorrect")
                    }
                    else {
                        return res.status(200).json({ message: "You have been successfully logged in!"})
                    }
                }
                else {
                    res.status(403).json({ message: "Your email is not registered. Please register to continue!" })
                    throw new Error("Your email is not registered. Please register to continue!")
                }
            }
            else {
                const isUserPresent = await ngoModel.findOne({ email })
                if (isUserPresent) {
                    if (password != isUserPresent.password) {
                        res.status(402).json({ message: "Password incorrect" })
                        throw new Error("Password incorrect")
                    }
                    else {
                        return res.status(200).json({ message: "You have been successfully logged in!", user:isUserPresent.name})
                    }
                }
                else {
                    res.status(403).json({ message: "Your email is not registered. Please register to continue!" })
                    throw new Error("Your email is not registered. Please register to continue!")
                }
            }
        }
        else {
            res.status(403).json({message : "Please fill all the fields!"})
            throw new Error("Please fill all the fields!")
        }
    }
    catch(err) {
        res.status(400)
        throw new Error(err)
    }
}
module.exports = {
    userRegister,
    userLogin
}