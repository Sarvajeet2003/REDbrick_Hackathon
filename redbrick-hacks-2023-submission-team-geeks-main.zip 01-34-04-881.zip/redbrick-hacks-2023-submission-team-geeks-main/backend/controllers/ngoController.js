const express = require('express');
const ngoModel = require('../models/ngoModel');
const donorModel = require('../models/donorModel');
const nodemailer = require('nodemailer')

const sendEmail = async (name, email) => {
    if (email&&name) {
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: "tusharc20001@gmail.com",
                pass: "udfmjqntdpovoaoi",
            },
        });
        const mailoptions = {
            from: "tusharc20001@gmail.com",
            to: email,
            subject: "Booked!!",
            html: `Booking Confirmation: We are delighted to inform you that ${name} has successfully booked your NGO's services`
        }
        // res.status(200).json({
        //     message:"Otp sent successfully"
        // })
        await transporter.sendMail(mailoptions)
    }
    else {
        res.status(400).json({
            message: "Email is required"
        })
    }
}
const mapDonorToNgo = async (req, res) => {
    try {
        const allngos = await ngoModel.find({})
        var data = []
        for (const ngo in allngos) {
            const temp = {
                name: allngos[ngo].name,
                email: allngos[ngo].email,
                phone: allngos[ngo].phone_no
            }
            data.push(temp)
        }
        res.status(200).json(data)
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
}

const selectNgo = async (req, res) => {
    const { dEmail, nEmail } = req.body
    try {
        const isemailpresent = await ngoModel.findOne({ nEmail })
        if (!isemailpresent) {
            res.status(404).json({msg: "No ngo found with this email id!"})
        }
        else {
            const donor = await donorModel.findOne({ dEmail })
            sendEmail(donor.name, nEmail)
            res.status(200).json({msg: "Ngo booked successfully!"})
        }
    }
    catch (err) {
        console.error(err);
        return res.status(500).json({ error: 'An error occurred' });
    }
}

module.exports = {
    mapDonorToNgo,
    selectNgo
};


