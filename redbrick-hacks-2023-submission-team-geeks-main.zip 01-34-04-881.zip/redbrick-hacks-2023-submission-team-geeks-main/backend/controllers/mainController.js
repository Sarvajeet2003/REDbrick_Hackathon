const express = require('express');
const router = express.Router();
const NGO = require('../models/NGO'); // Replace with your NGO model
const Donor = require('../models/Donor'); // Replace with your Donor model

const mapDonorToNgo = async (req, res) => {
    try {
        const ngos = await NGO.find();
        const donors = await Donor.find();

        // Function starts
        function calculateDistance(lat1, lon1, lat2, lon2) {
            const R = 6371; // Radius of the Earth in kilometers

            const lat1Rad = toRadians(lat1);
            const lon1Rad = toRadians(lon1);
            const lat2Rad = toRadians(lat2);
            const lon2Rad = toRadians(lon2);

            const dLat = lat2Rad - lat1Rad;
            const dLon = lon2Rad - lon1Rad;

            const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(dLon / 2) ** 2;
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

            const distance = R * c;
            return distance;
        }

        function toRadians(degrees) {
            return (degrees * Math.PI) / 180;
        }
        // Function Ends
        
        for (const donor of donors) {
            let nearestNgo = null;
            let nearestDistance = Infinity;

            for (const ngo of ngos) {
                const distance = calculateDistance(
                    donor.location.latitude,
                    donor.location.longitude,
                    ngo.location.latitude,
                    ngo.location.longitude
                );

                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearestNgo = ngo;
                }
            }

            donor.matched_ngo = nearestNgo._id; // Assuming you have a reference field matched_ngo in Donor model
            await donor.save();

            nearestNgo.matched_Donor.push(donor._id); // Assuming you have a reference field matched_Donor in NGO model
            await nearestNgo.save();
        }

        return res.render('mapping_complete'); // Assuming you have a template for mapping complete
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'An error occurred' });
    }
}

module.exports = router;
