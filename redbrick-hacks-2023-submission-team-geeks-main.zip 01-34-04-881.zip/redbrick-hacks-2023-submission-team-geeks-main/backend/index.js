const express = require('express')
const app = express()
const cors = require('cors')
const mongoose = require('mongoose')
app.use(cors())
app.use(express.json())
const authroute = require('./routes/authroutes')
const ngoroute = require('./routes/ngoroutes')

const connection_url = 'mongodb+srv://sarvajeeth21417:HhJzePCNWYpkduSf@cluster0.laaviq9.mongodb.net/?retryWrites=true&w=majority'
// app.use(bodyParser.urlencoded({ extended: true }));
mongoose.set('strictQuery', true);
mongoose.connect(connection_url, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("MongoDB connected");
    })
app.use('/api/auth',authroute)
app.use('/api/ngo',ngoroute)

app.listen(3000)