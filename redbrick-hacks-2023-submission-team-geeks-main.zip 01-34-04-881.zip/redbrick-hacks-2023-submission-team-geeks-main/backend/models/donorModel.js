const mongoose = require('mongoose')

const donorSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true 
    },
    email: {
        type: String,
        required: true
    },
    phone_no: {
        type: Number,
        // required: true
    },
    password: {
        type: String,
        required:true
    }
})
const donorModel = mongoose.model('Donor', donorSchema)
module.exports = donorModel;