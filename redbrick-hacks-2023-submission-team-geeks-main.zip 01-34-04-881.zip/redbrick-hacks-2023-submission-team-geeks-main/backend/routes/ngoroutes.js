const express = require('express')
const {mapDonorToNgo, selectNgo} = require('../controllers/ngoController')
const route = express.Router()

route.get('/ngolist', mapDonorToNgo)
route.post('/selectngo', selectNgo)

module.exports = route